let cart = JSON.parse(localStorage.getItem("cart")) || [];

// Add to Cart
function addToCart(name, price) {
  cart.push({ name, price });
  localStorage.setItem("cart", JSON.stringify(cart));
  alert(name + " added to cart!");
}

// Display Cart
function displayCart() {
  let cartItems = document.getElementById("cart-items");
  let total = 0;

  if (!cartItems) return;

  cartItems.innerHTML = "";

  cart.forEach((item) => {
    cartItems.innerHTML += `<p>${item.name} - Rs.${item.price}</p>`;
    total += item.price;
  });

  document.getElementById("total").innerText = "Total: Rs." + total;
}

displayCart();

// Search Products
function searchProducts() {
  let input = document.getElementById("search").value.toLowerCase();
  let products = document.querySelectorAll(".product-card");

  products.forEach((product) => {
    let name = product.querySelector("h2").innerText.toLowerCase();
    product.style.display = name.includes(input) ? "block" : "none";
  });
}
